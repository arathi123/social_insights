import React from 'react';
import ReactDOM from 'react-dom';
import 'script!jquery';
import 'script!foundation-sites/dist/foundation.min.js';
import 'script!timeago';
import TopBar from './TopBar.js';
import Content from './Content.js';
import LeftPane from './LeftPane';
import Update from 'react-addons-update';
import { browserHistory, Router, Route, Link, withRouter , IndexRoute } from 'react-router'


require('foundation-sites/dist/foundation.min.css');
require('../css/foundation-icons/foundation-icons.css');
require('../css/home.css');
require('../images/pageloader.gif');

var sampleComments = require('./sampleComments');

var Home = React.createClass({
	  getInitialState() {
	  	return {'feed':[],'loadingFeed':false};
	  },
	  getFeed(options,callBack){
	  	if (!this.state.loadingFeed){
		  	$('.se-pre-con').show();
		    $.ajax({
			  dataType: "json",
			  url: '/feed' ,
			  data: options,
			  beforeSend: () => setTimeout(() => this.setState({'loadingFeed':true}),0),
			  success: (feed) => {
				callBack(feed);
	            $('.se-pre-con').hide();
			  },
			  complete: () => this.setState({'loadingFeed':false})
			});
	  	} else {
	  		console.log("ajax request already in progress",this.state.feedOptions);
	  	}
	  },
	  getSmAccounts(){
	    $.ajax({
		  dataType: "json",
		  url: '/sm_accounts' ,
		  success: function(smAccounts){
		  	if (smAccounts.sm_accounts.length>0){
			  	this.setState({'smAccounts':smAccounts.sm_accounts});
		  	}
		  }.bind(this)
		});

	  },
	  fetchNextPage(){
	  	if (!this.state.feedOptions.allPagesFetched){
	  		let options =Update(this.state.feedOptions,{
	  			'page': {$apply: (page)=> page+1},
	  		});
	      	let updateState = (feed) => {
	      		if (feed.length > 0 ){
		      		let newState =Update(this.state,{
		      			'feed': {$push: feed},
		      			'feedOptions': {$set:options}
		      		});
			        this.setState(newState);
	      		} else {
		      		let newState =Update(this.state,{
		      			'feedOptions': { 'allPagesFetched' : {$set:true}}
		      		});
			        this.setState(newState);

	      		}
	      	};
		  	this.getFeed(options,updateState);
	  	}
	  },
	  getInitialState(){
	  	return {
	  		selectedPage: {name:'',id:''},
	  		following : [],
	  		currentStep: 0,
	  		feed: [],
	  		smAccounts: []
	  	}
	  },
	  handleHomeClick(){
        var selectedElement = document.getElementById(this.state.selectedPage.id);
      	selectedElement.className ="paneItem";
      	let options = {page:1, access_token:userInfo.access_token};
  	    this.getFeed(options,(feed)=>this.setState({'feed':feed,currentStep:2,feedOptions:options}));
	  },
	  handleSelect(value){
	  	this.setState({selectedPage:value,currentStep:1});
	  },
	  handleFollowEvent(smAccount,type){
	    if (type === 'follow'){
	         let newState = Update(this.state,
	                                {'smAccounts' : {$apply:(smAccounts) =>
                                        {
                                            smAccounts.push(smAccount);
                                            return smAccounts;
                                        }
	                                }
	                                });
	         this.setState(newState);
	    } else if (type === 'unfollow'){
             let newState = Update(this.state,
                                    {'smAccounts' : {$apply:(smAccounts) =>
                                      {
                                          var ix = -1;
                                          for(var i=0; i < smAccounts.length; i++){
                                            if (smAccounts[i].id == smAccount.id){
                                                ix = i;
                                            }
                                          }
                                          if (ix > -1 ){
                                              smAccounts.splice(ix,1);
                                          }
                                          return smAccounts;
                                      }
                                    }
                                    });
             this.setState(newState);
	    }
	  },
	  componentDidMount(){
      	let options = {page:1, access_token:userInfo.access_token};
  	    this.getFeed(options,(feed)=>this.setState({'feed':feed,currentStep:2,feedOptions:options}));
	  	this.getSmAccounts();
		$(document).foundation();
	  },
	  handlePageFilter(pageNumber,smAccountId,smAccountName){
	  	if($('#pageList').find('.selectedItem').size()!=0){
		  	var prevElement=$('#pageList').find('.selectedItem')[0]
		  	prevElement.className="paneItem"; 
		  }
	  	var currentElement = document.getElementById(smAccountId);
	  	currentElement.className ="selectedItem";
	  	console.log('handling filter click');
	  	let options = {
			page : pageNumber,
			sm_account_id: smAccountId,
			access_token: userInfo.access_token
		 };
		let updateState = (feed) => {
		    this.state.selectedPage.name=smAccountName;
		    this.state.selectedPage.id=smAccountId;
            this.setState({'feed':feed,currentStep:2,feedOptions:options});
		};
		this.getFeed(options,updateState);
	  },
	  render(){
	    return(
	      <div>
	     	 <img src="static/images/pageloader.gif" className="se-pre-con" style={{'display':'none'}} />
	          <TopBar userName={userInfo.fb_user_name} selectionHandler={this.handleSelect} 
	          clickHandler={this.handleHomeClick} smAccounts={this.state.smAccounts} pageFilter={this.handlePageFilter}/>		       
		      		      		      
	      </div>
	    );
	  }
});

module.exports = Home;
