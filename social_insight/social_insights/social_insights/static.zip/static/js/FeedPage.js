import React from 'react';
import PostContent from './PostContent.js';

var FeedPage = React.createClass({
  render(){
    return(
    	<PostContent 
    	messages={this.props.feed}
    	fetchNextPage={this.props.fetchNextPage}
    	/>
    );
  }

});

module.exports = FeedPage;