import React from 'react';
import ReactDOM from 'react-dom';
import 'script!jquery';
import 'script!foundation-sites/dist/foundation.min.js';
import 'script!timeago';
import Home from './home.js';
import TopBar from './TopBar.js';
import LeftPane from './LeftPane.js';
import HM from './HM.js';
import TB from './TB.js';
import Content from './Content.js';
import LP from './LP.js';
import About from './About';
import Update from 'react-addons-update';
import { browserHistory, Router, Route, Link, withRouter , IndexRoute } from 'react-router'

require('foundation-sites/dist/foundation.min.css');
require('../css/foundation-icons/foundation-icons.css');
require('../css/home.css');
require('../images/pageloader.gif');

ReactDOM.render((<Router history={browserHistory}>
    <Route path="/" component={HM}>
	    <Route path="/smaccounts" component={LP} />
	   		<Route path="/smaccounts/:name" component={Content}/>
    </Route>
  </Router>),document.getElementById('container'));









// ReactDOM.render((<Router history={browserHistory}>
//     <Route path="/" component={Home}>
// 	    <Route path="/smaccounts" component={LeftPane} />
// 	   		<Route path="/smaccounts/:name" component={Content}/>
//     </Route>
//   </Router>),document.getElementById('container'));


















// import React from 'react'
// import { render } from 'react-dom'
// import { Router, Route, browserHistory } from 'react-router'
// import App from './App'
// import About from './About'
// import Repos from './Repos'

// render((
//   <Router history={browserHistory}>
//     <Route path="/" component={App}>
//       {/* make them children of `App` */}
//       <Route path="/repos" component={Repos}/>
//       <Route path="/about" component={About}/>
//     </Route>
//   </Router>
// ), document.getElementById('container'))