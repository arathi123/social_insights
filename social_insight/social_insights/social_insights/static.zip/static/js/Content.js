import React from 'react';
import LaunchPage from './LaunchPage.js';
import FeedPage from './FeedPage.js';
import FollowPage from './FollowPage.js';

var Content = React.createClass({
  
  getInitialState(){
    return ({ formValues: {} });
  },
  updateFormData(formData,nextStep) {
    var formValues = Object.assign({}, this.state.formValues, formData);
    console.log(formValues);
    this.setState({formValues: formValues});
  },
  render() {
    return <div> {this.props.params.name} </div>
  }

});

module.exports = Content;