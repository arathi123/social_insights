import React from 'react';

var FollowPage = React.createClass({
  getFollowStatus(pageId){
     var following = this.props.smAccounts.some(function(elem){ return elem.id == pageId}.bind(this));
     return following;
  },
  getInitialState(){
  	return {
  		'following': this.getFollowStatus(this.props.page.id)
  	};
  },
  handleSubmit(event){
  	event.preventDefault();
    $.ajax({
	  type: "POST",
	  url: '/sm_accounts' ,
	  data: {
		sm_account_id : this.props.page.id,
		sm_domain: this.props.page.name,
		action : this.state.following ? 'unfollow' : 'follow'
	  },
	  success: function(status){
        var smAccount = {'id':this.props.page.id,'name':this.props.page.name};
	    if (this.state.following){
            this.props.handleFollowEvent(smAccount,'unfollow');
	    } else{
            this.props.handleFollowEvent(smAccount,'follow');
	    }
	  	this.setState({'following':!this.state.following});
	  }.bind(this)
	});
  },
  componentWillReceiveProps(nextProps){
     var following = this.getFollowStatus(nextProps.page.id);
     this.setState({'following':following});
  },
  render(){
  	var imageUrl = "http://graph.facebook.com/"+ this.props.page.id + "/picture?type=large"; 
    return(
      <div>
	     <form onSubmit={this.handleSubmit}>
	        <div className='small-12 column row post-row mainCanvas'  >
	            <div className='row'>
		            <div className='small-4 column pageProfilePicture '>
		            	<img src={imageUrl}/>
		            </div>
		            <div className='small-8 column'>
				      <h4> 
				      	<a href={'http://facebook.com/'+this.props.page.id} target='_blank'> 
				      		{this.props.page.name} 
				      	</a>
				      </h4>
				      <h6 className='subheader'> {this.props.page.fan_count + ' Fans'} </h6>
				      <p> {this.props.page.about } </p>
				      <input type="submit" value={this.state.following ? 'Following':'Follow'} className={this.state.following ? 'button success':'button'}/>
				    </div>
	      		</div>
			</div>
		</form>
      </div>
    );
  }
});

module.exports = FollowPage;