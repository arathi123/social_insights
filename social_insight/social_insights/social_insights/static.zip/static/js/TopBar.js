import React from 'react';
import PageSearch from './PageSearch';
import LeftPane from './LeftPane';

import { browserHistory, Router, Route, Link, withRouter } from 'react-router'

var TopBar = React.createClass({
handleClick(){
	if('clickHandler' in this.props){
		this.props.clickHandler()
	}
},
render(){
	return(
		<div>
			<div data-sticky-container>
				<div className="title-bar" data-responsive-toggle="example-menu" data-hide-for="medium">
				  <button className="menu-icon" type="button" data-toggle></button>
				  <div className="title-bar-title">Menu</div>
				</div>
				<div className="top-bar" id="example-menu" data-sticky data-options="marginTop:0;" style={{'width':'100%'}}>
				  <div className="small-12 column row">
					  <div className="top-bar-left">
					    <ul className="dropdown menu" data-dropdown-menu>
					      <li className="menu-text menu-title hide-for-small" onClick={this.handleClick}>
					      <Link to="/">Sosilee</Link> </li>
					    </ul>
					  </div>
					  <div className="top-bar-right">
					    <ul className="menu">
					      <li><i className="step fi-magnifying-glass size-24"></i></li>
					      <li><PageSearch selectionHandler={this.props.selectionHandler}/></li>
					      <li>
					       	  <ul className="dropdown menu" data-dropdown-menu>
					       	      <li>
								      <a href="#"> <i className="fi-widget size-24"> </i> </a>
								        <ul className="menu vertical">
								          <li> {this.props.userName} </li>
								          <li><a href={'/logout'}> Logout </a></li>
								        </ul>
								   </li>
							 </ul> 
					      </li>
					    </ul>
					  </div>
					</div>
				</div>
			</div>
			<LeftPane smAccounts={this.props.smAccounts} pageFilter={this.props.pageFilter}/>
		</div>
		);
}
});

module.exports = TopBar;
